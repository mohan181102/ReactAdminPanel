const Backend_Url = window.SERVER_PORT.URL

export default Backend_Url;
