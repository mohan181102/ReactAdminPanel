import { createContext } from 'react';

const UpdateContex = createContext();

export default UpdateContex;

